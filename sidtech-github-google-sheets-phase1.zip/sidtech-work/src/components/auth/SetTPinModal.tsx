import React, { useState } from 'react';
import { ShieldCheck, KeyRound, Lock, Eye, EyeOff, AlertCircle, CheckCircle2, ShieldAlert } from 'lucide-react';
import { SidTechDatabase } from '../../services/storage';
import { Franchise } from '../../types/database';

interface SetTPinModalProps {
  franchise: Franchise;
  onSuccess: (updatedFranchise: Franchise) => void;
}

export const SetTPinModal: React.FC<SetTPinModalProps> = ({ franchise, onSuccess }) => {
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanPin = pin.trim();
    const cleanConfirm = confirmPin.trim();

    if (!/^\d{4}$/.test(cleanPin)) {
      setError('Transaction PIN (T-PIN) must be exactly 4 numeric digits (0-9).');
      return;
    }

    if (cleanPin !== cleanConfirm) {
      setError('T-PIN numbers do not match. Please re-enter carefully.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = SidTechDatabase.setFranchiseTPin(franchise.franchiseId, cleanPin);
      if (res.success) {
        const refreshed = SidTechDatabase.getFranchiseById(franchise.franchiseId);
        if (refreshed) {
          onSuccess(refreshed);
        }
      } else {
        setError(res.message);
        setIsSubmitting(false);
      }
    } catch {
      setError('Failed to configure T-PIN. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border-2 border-[#E86A17]">
        {/* Header */}
        <div className="bg-[#12294A] px-6 py-5 text-white border-b-2 border-[#E86A17] flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#E86A17] flex items-center justify-center font-bold text-white shadow-md">
            <KeyRound className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-extrabold text-base text-white">
              First-Time Security Setup
            </h3>
            <p className="text-xs text-orange-200 font-medium">
              Create Your 4-Digit Transaction Security PIN (T-PIN)
            </p>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          <div className="p-3.5 bg-orange-50 border border-orange-200 rounded-xl text-xs text-orange-950 leading-relaxed flex items-start gap-2.5">
            <ShieldAlert className="w-4 h-4 text-[#E86A17] flex-shrink-0 mt-0.5" />
            <div>
              <strong className="font-bold block text-orange-900 mb-0.5">
                Mandatory Security Requirement
              </strong>
              For your account safety, this 4-digit T-PIN is strictly required to authorize{' '}
              <strong>wallet withdrawals</strong> and <strong>password changes</strong>. Keep it confidential.
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Enter 4-Digit T-PIN <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type={showPin ? 'text' : 'password'}
                  inputMode="numeric"
                  pattern="[0-9]*"
                  maxLength={4}
                  required
                  value={pin}
                  onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                  placeholder="• • • •"
                  className="w-full text-center text-2xl font-mono tracking-widest font-black py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#E86A17] focus:bg-white"
                />
                <button
                  type="button"
                  onClick={() => setShowPin(!showPin)}
                  className="absolute right-3 top-3.5 text-slate-400 hover:text-slate-600"
                >
                  {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Confirm 4-Digit T-PIN <span className="text-rose-500">*</span>
              </label>
              <input
                type={showPin ? 'text' : 'password'}
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={4}
                required
                value={confirmPin}
                onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                placeholder="• • • •"
                className="w-full text-center text-2xl font-mono tracking-widest font-black py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#E86A17] focus:bg-white"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting || pin.length !== 4 || confirmPin.length !== 4}
                className="w-full py-3 bg-[#E86A17] hover:bg-[#d45e12] disabled:opacity-50 text-white rounded-xl text-sm font-bold shadow-md transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{isSubmitting ? 'Configuring Security PIN...' : 'Save T-PIN & Enter Portal'}</span>
              </button>
            </div>
          </form>

          <div className="text-center text-[11px] text-slate-400">
            Account: <strong className="text-slate-700 font-mono">{franchise.franchiseId}</strong> ({franchise.branchName})
          </div>
        </div>
      </div>
    </div>
  );
};
