<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/2522efd1-053f-4ee5-b69d-0c8ca8fe76ac

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Google Sheets Backend Migration

The project now includes `backend/apps-script/` and `src/services/remoteApi.ts` as the foundation for the Google Sheets migration.
See `backend/apps-script/README.md` for setup. The UI remains unchanged in this phase.
